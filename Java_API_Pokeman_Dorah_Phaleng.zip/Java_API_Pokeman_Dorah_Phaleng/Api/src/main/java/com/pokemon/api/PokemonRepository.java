package com.pokeman.api;

import org.springframework.data.repository.crudRepository;
import org.springframework.stereotype.Repository;


import java.util.List;

@Repository
public interface PokemonRepository extends CrudRepository<Pokemon,Long>{
	List<Pokemon> findAllByOrderIdAsc();
}