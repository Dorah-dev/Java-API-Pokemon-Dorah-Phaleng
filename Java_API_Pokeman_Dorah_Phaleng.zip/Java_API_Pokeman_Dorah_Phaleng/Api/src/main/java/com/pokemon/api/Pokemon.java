package com.pokemon.api;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "pokemon")
public class pokemon {


@Id
@Generatedvalue(strategy = GenerationType.IDENTITY)

	private Long id;
	private string name;
	private string imagefront;
	private string imageback;
	private int quantity;

	public pokemon() {}

	public Pokemon(String name, String imagefront, String imageback, int quantity){
		this.name = name;
		this.imagefront = imagefront;
		this.imageback = imageback;
		this.quantity = quantity;

}

public Long getId(){
	return id;
}
public String getName(){
	return name;
}

public void setName(String name){
	this.name = name;
}

public String getImagefront(){
	return imagefront;
}
public void setImagefront(String image){
	this.imagefront = imagefront;
}
public string getImageback(){
	return imageback;
}
public void setImageback(String imageback){
	this.imageback = imageback;
}
public int getQuantity(){
	return quantity;
}
public void setQuantity(int quantity){
	this.quantity = quantity;
}