import{} from '@heroicons/react/outline'
import { useState} from "react";

export default function PokemonForm(){
	const [newPokemon,setNewPokemon] = useState({

name: '',
imagefront: '',
imageback: '',

	});

const mutationCreatePokemon = useCreatePokemon();

	const handleSubmit = e => {
	e.preventDefault();
	mutationCreatePokemon.mutate(newPokemon);
	};


	return <form className="inline-grid" onSubmit={handleSubmit}>
	<input type="text" className= "rounded-md border-slate-300 shadow-md p-2 mb-2"
	placeholder="enter name"
	value={newPokemon.name}
	required
	onChange={e => setNewPokemon({...newPokemon, name: e.target.value})}

	/>
<input type="text" className= "rounded-md border-slate-300 shadow-md p-2 mb-2"
	placeholder="enter back image"
	value={newPokemon.imagefront}
	required
	onChange={e => setNewPokemon({...newPokemon, name: e.target.value})}
	/>
	<button type='submit'>
	<saveIcon className="h-5 w-5 mr-1"/>
	<span>save</span>
	</button>
	</form>
);
}